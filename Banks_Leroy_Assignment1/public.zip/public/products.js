var products =
    [
        {
            "brand": "Jordan 8 Retro",
            "price": "134.97",
            "image": './images/Jordan_8_Retro.jpg'
        },
        {
            "brand": "Jordan 9 Retro",
            "price": "140.65",
            "image": './images/Jordan_9_Retro.jpg'
        },
        {
            "brand": "Jordan 10 Retro",
            "price": "140.55",
            "image": './images/Jordan_10_Retro.jpg'
        },
        {
            "brand": "Jordan 11 Retro",
            "price": "285.15",
            "image": './images/Jordan_11_Retro.jpg'
        },
        {
            "brand": "Jordan 12 Retro",  // All my products data that will show the visual of my shoe products
            "price": "140.75",
            "image": './images/Jordan_12_Retro.jpg'
        }
    ];
if (typeof module != 'undefined') {
    module.exports.products = products;
}